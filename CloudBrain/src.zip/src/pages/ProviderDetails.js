import React, { Component } from "react";
import {
  View,
  FlatList,
  TouchableOpacity,
  Image,
  Text
} from "react-native";

import ProviderDetailsRowsFlatlist_STYLES from "../GlobalStylesheet/ProvidetailsRowsFlatlist";
import NavigationService from '../Util/Navigation/NavigationService';

import { ListItem } from "native-base";

export default class ProviderDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isNetworkConnected: false,
      isActivityLoading: false,
      prevProp: null,
      dataSource: [],
      currentActionType: "",
      
    };
  }

  componentDidMount() {
    this.startActivityIndicator
    console.log('navigation param', this.props.navigation.state.params.selectedVmsForProvider);

    let vmResources = this.props.navigation.state.params.selectedVmsForProvider.data.resources

    this.setState({
      dataSource: vmResources
    });
  }

 

  static navigationOptions = {
    title: "Provider Details",
    headerLeft: (

      <TouchableOpacity  onPress={() => NavigationService.navigate('DashboardObj')}>
           <Image
             source={require('../resources/Images/arrow-left.png')}
             style={{ width: 20, height: 30, marginLeft: 5 }}
           />
  
      </TouchableOpacity>
           )
  };

  render() {
    return (
      <View style={ProviderDetailsRowsFlatlist_STYLES.MainContainer}>
     
        <FlatList
          data={this.state.dataSource}
          renderItem={({ item }) => (
            <ListItem noBorder={true}>
            {/* Take parent view holding two views as - flexRow */}
              <View style={ProviderDetailsRowsFlatlist_STYLES.cellParentView}>
                
                {/*1. 1st innerParent will hold content as - flexRow */}
                <TouchableOpacity style={ProviderDetailsRowsFlatlist_STYLES.firstInnerParentCellView}>
                  <Image style={ProviderDetailsRowsFlatlist_STYLES.osImageIcon}
                        source={this.checkOsImage(item.operating_system.product_name.toUpperCase())}/>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.osNameText}>{item.name}</Text> 
                  <View style={this.checkPowerState(item.power_state)}>
                  <Image style={ProviderDetailsRowsFlatlist_STYLES.statusIcon}
                        source={require("../resources/Images/Power-icon.png")}/>
                  </View>
                </TouchableOpacity>

                {/*1. 2nd innerParent will hold content as - flexColumn */}
                <View style={ProviderDetailsRowsFlatlist_STYLES.secondInnerParentFooterView}>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooterContents}>Availability zone: {item.availability_zone.name}</Text>

                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooter_HEADING}>Hardware</Text>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooterContents}>Virtualization type: {item.hardware.virtualization_type}</Text>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooterContents}>Root Device type: {item.hardware.root_device_type}</Text>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooterContents}>Memory: {item.hardware.memory_mb} MB</Text>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooterContents}>Architecture: {item.hardware.bitness} bit</Text>

                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooter_HEADING}>Flavor</Text>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooterContents}>Description: {item.flavor.description}</Text>
                  <Text style={ProviderDetailsRowsFlatlist_STYLES.cellFooterContents}>CPUs: {item.flavor.cpu_cores}</Text>
                  
                </View>
              </View>
            </ListItem>
          )}
          keyExtractor={(item, index) => index}
        />
      </View>
    );
  }

  checkPowerState(powerState) {
    if (powerState.includes('on')) {
        return ProviderDetailsRowsFlatlist_STYLES.onStatusView
    } 
    else {
       return ProviderDetailsRowsFlatlist_STYLES.ofStatusView
    }
  }

  checkOsImage(osName) {
    if (osName.includes("centos".toUpperCase())) {
      return require("../resources/Images/centos.png");
    } else if (osName.includes("debian".toUpperCase())) {
      return require("../resources/Images/debian.png");
    } else if (osName.includes("fedora".toUpperCase())) {
      return require("../resources/Images/fedora.png");
    } else if (osName.includes("linux".toUpperCase())) {
      return require("../resources/Images/linux.png");
    } else if (osName.includes("redhat".toUpperCase())) {
      return require("../resources/Images/redhat.png");
    } else if (osName.includes("ubuntu".toUpperCase())) {
      return require("../resources/Images/ubantu.png");
    } else {
      return require("../resources/Images/window.png");
    }
  }

}
