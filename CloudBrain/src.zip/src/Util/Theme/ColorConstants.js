 
  const COLORS = {
 
  lightBlue : "rgba(244,252,255,1)",
  skyBlue : "rgba(72,135,243,1)",
  appBlueTheme : 'rgba(90, 132, 248, 1)',
  DrawerText : '#3C446B',
 }

export default COLORS;

