const API_CONST = {

	
    N_USER_LOGIN					:			'N_USER_LOGIN',
    N_GET_USER_DETAILS              :           'N_USER_GET_DETAILS',
    N_GET_PROVIDERS                 :           'N_GET_PROVIDERS',
    N_GET_VMS_FOR_PROVIDER          :           'N_GET_VMS_FOR_PROVIDER',
	
}
export default API_CONST

