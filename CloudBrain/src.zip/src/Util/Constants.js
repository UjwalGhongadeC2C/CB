




const CONST = {

	
 k_auth : 'auth',
 k_groupName : 'groupName',
 k_userData : 'userData',
 


	
}
export default CONST


