import { combineReducers } from 'redux';
import LoginReducer from './LoginReducer';
import ProviderReducer from './ProviderReducer';


export default combineReducers({
  loginReducer: LoginReducer,
  providerReducer: ProviderReducer
  
});